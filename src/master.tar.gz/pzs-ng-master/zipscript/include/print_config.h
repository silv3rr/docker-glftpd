#ifndef PRINTCONFIG_H_200706231538
#define PRINTCONFIG_H_200706231538

void print_nondefault_config(void);
void print_full_config(void);

#endif
