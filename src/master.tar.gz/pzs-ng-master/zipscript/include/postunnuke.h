#ifndef POSTUNNUKE_H
#define POSTUNNUKE_H

#define UNNUKE_STR "site unnuke "
#define UNNUKE_STRLEN 12

#endif
